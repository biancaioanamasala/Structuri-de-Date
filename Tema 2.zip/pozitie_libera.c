#include "pozitie_libera.h"


DateIntrare* citeste_fisier_in(char *nume_fisier_intrare) {
    // TODO citeste datele din fisier si populeaza pointerul la structura
    return NULL;
}


int* calculeaza_vector_raspuns(DateIntrare *date_intrare) {
    // TODO creeaza vectorul raspuns folosind arbori de intervale
    return NULL;
}


int* calculeaza_vector_raspuns_trivial(DateIntrare *date_intrare) {
    // TODO creeaza vectorul raspuns folosind 2 for-uri
    return NULL;
}